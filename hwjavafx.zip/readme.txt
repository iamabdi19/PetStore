Isim :Abdirahman Abdiweli Osman: wrote the user interface code w/ Hakan
ID:20050141037
Isim; Ahmed Hakan Ozturk: wrote the the user interface code w/ Abdi
ID:20050141002
Isim : Hamza Guelleh Ali: tested the code and looked for bugs before submission
ID; 20050141021

follow the steps below to run the file;

i) access the zip file
ii) then open HwJavafx
iii) then open src file
iv) then double click and run the HwJavafx class cause it contains the main method

